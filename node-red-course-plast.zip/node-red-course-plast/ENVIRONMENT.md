PORT=3000 - Application port. Do not change or set manually.  
NODE_ENV={development,production} - application environment (Default: production)  
TIMEZONE=UTC - timezone in logs (https://momentjs.com/timezone/)  
