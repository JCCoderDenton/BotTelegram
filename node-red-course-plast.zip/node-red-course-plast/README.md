# void-nodered-repo
Templete repository with configured actions and branch restrictions
## Private palletes
Create file .npmrc with content of [exapmple.npmrc](example.npmrc) and replace `${GITHUB_TOKEN}` with your GIHUB_TOKEN.
GIHUB_TOKEN is token generated in your account with read rights for github packages and repo
