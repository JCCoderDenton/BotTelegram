module.exports = {
  apps: [
    {
      name: "node-red-bot",
      script: "C:/Users/Denys/AppData/Roaming/npm/node_modules/node-red/red.js",
      args: "-s settings.js -u ./",
      watch: false,
      node_args: "--max_old_space_size=1500",
      autorestart: true,
      env: {
        NODE_ENV: "LOCAL",
        CUSTOMER_API_URL: 'http://core-apps.dev.chatbots.vpc:8080/core-customer-api',
        CUSTOMER_API_KEY: '?aM-dUZVF@ZWJvq5Y2?Bfrs5j=A9?+sb',
        MESSAGES_API_URL: 'http://core-apps.dev.chatbots.vpc:8080/core-messages-api',
        MESSAGES_API_KEY: 'h5@8WzM%KFhxMf!r!P_m6WM=VJvgef?q',

     /* IMAGES_API_URL: "здесь ваш урл",
        IMAGES_API_KEY: "здесь ваш токен",
        API_WRAPPER_INTERNAL_URL: "здесь ваш урл",
        API_WRAPPER_INTERNAL_KEY: "здесь ваш токен",
        API_WRAPPER_EXTERNAL_URL: 'здесь ваш урл',
        API_WRAPPER_EXTERNAL_KEY: 'здесь ваш токен',
        WEBVIEW_URL: "здесь ваш урл",*/
        BOT_ID: '11',
        CHANNEL: 'TG',
        COMPANY_ID: '43',
        APPLICATION_NAME: "NodeRed",
      //  GROUP_ID: "-605353742",
        GROUP_ID: "-672992123",
        PORT:1880
      }/*,
      env_dev: {
      }*/
    },
  ],
};
